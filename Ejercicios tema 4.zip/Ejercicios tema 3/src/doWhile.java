public class doWhile {

    public static void main(String[] args) {
        int x = 1;
        do
        {
            System.out.println("Valor de X es : " + x);
            x++;
        }while( x <= 1);
    }
}
