public class Switch {
    public static void main(String[] args) {
        String estacion = "Primavera";

        switch (estacion)
        {
            case "Verano":
                System.out.println("Es Verano");
                break;
            case "Otono":
                System.out.println("Es Otoño");
                break;
            case "Invierno":
                System.out.println("Es Invierno");
                break;
            case "Primavera":
                System.out.println("Es Primavera");
                break;
            default:
                System.out.println(" Estacion Invalida");
            break;
        }
    }
}
