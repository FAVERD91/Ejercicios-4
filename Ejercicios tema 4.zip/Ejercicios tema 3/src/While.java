public class While {
    public static void main(String[] args) {
        int x = 0;
        while( x <= 3)
        {
            System.out.println("Valor de X es : " + x);
            x++;
        }
    }
}
